import numpy as np
import os
import pandas as pd
from numpy import log
import itertools
import matplotlib.pyplot as plt


class PgmReader:
    def __init__(self, path: str):
        self.path: str = path

    def read(self) -> list:
        with open(self.path, 'rb') as file:
            format: str = file.readline().decode('utf-8').strip()
            assert format == "P5"
            (width, height) = [int(i) for i in file.readline().split()]
            depth: int = int(file.readline())
            assert depth == 255
            raster: list = []
            for y in range(height):
                row = []
                for y in range(width):
                    row.append(ord(file.read(1)))
                raster.append(row)
            return raster


def generate_histogram(distribution, data_base_path):
    name, data = distribution
    x, y = np.unique(data, return_counts=True)
    plt.figure(1)
    plt.bar(x, y)
    plt.title(f" {name} histogram")
    plt.ylabel("frequency")
    plt.xlabel("random variable")
    plt.savefig(os.path.join(data_base_path, f"../histograms/{name}_histogram.png"))
    plt.clf()


def calcualte_prob(data):
    values, frequencies = np.unique(data, return_counts=True)
    probabilities = frequencies / frequencies.sum()
    pd_dict = {
        "pixel_values": values,
        "pixel_count": frequencies,
        "pixel_prob": probabilities
    }
    return pd.DataFrame(pd_dict)


def simple_entropy(probabilities, log_base=256) -> float:
    fun = lambda prob: prob * log(prob) / log(log_base)
    return -fun(probabilities[probabilities != 0]).sum()


def block_entropy(probabilities, log_base=256):
    combinations_list = [p for p in itertools.product(probabilities, repeat=2)]
    prob_combinations = np.array([x1 * x2 for x1, x2 in combinations_list])
    return simple_entropy(prob_combinations, log_base)


class MarkovEntropy:
    def __init__(self, chain, log_base=256):
        self.chain = chain
        self.chain_length = len(chain)
        self.frequencies = dict(
            zip(np.unique(self.chain, return_counts=True)[0], np.unique(self.chain, return_counts=True)[1]))
        self.unique_values = list(self.frequencies.keys())
        self.stationary_prob = self._calculate_stationary_probabilities()
        self.cond_probabilities = self._calculate_cond_probabilities()
        self.log_base = log_base

    def _calculate_stationary_probabilities(self):
        probs = [freq / self.chain_length for freq in list(self.frequencies.values())]
        stationary_prob = dict(zip(self.unique_values, probs))
        return stationary_prob

    def _calculate_cond_probabilities(self):
        cond_occurences = {}
        for value in self.unique_values:
            cond_occurences[value] = dict(zip(self.unique_values, np.zeros(self.chain_length)))
        for i in range(1, self.chain_length):
            cond_occurences[self.chain[i]][self.chain[i - 1]] += 1

        for occurence_row in list(cond_occurences.keys()):
            for occurence_column in list(cond_occurences[occurence_row].keys()):
                cond_occurences[occurence_row][occurence_column] /= self.frequencies[occurence_column]
        return cond_occurences

    def calculate(self):
        entropy = 0
        for value in self.unique_values:
            stationary_prob = self.stationary_prob[value]
            if stationary_prob == 0:
                continue
            for cond_prob_id in self.unique_values:
                cond_prob = self.cond_probabilities[cond_prob_id][value]
                if (cond_prob == 0):
                    continue
                entropy += stationary_prob * cond_prob * log(cond_prob) / log(self.log_base)
        return -entropy


def avg_code_length(probs_with_length: dict):
    '''
    {
        "symbol":(prob,length]
    }
    '''
    result = 0
    for prob, length in probs_with_length.values():
        result += prob * length
    return result
