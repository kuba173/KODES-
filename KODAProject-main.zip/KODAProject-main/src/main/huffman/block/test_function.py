import sys

import numpy as np
from PIL import Image

from Block_encoding_and_decoding import huffman_encoding_func, huffman_decoding_func,huffman_encoding_func_par,huffman_decoding_func_par, huffman_encoding_image_par,huffman_decoding_image_par

with open("data.txt", "r") as file:
    content = file.read()

print("+++++++++++++++++++++++++++++++++++++++TEXT++++++++++++++++++++++++++++++++++++++")
print("The size of the data is: {}".format(sys.getsizeof(content)))
print("The content of the data is: {}".format(content))
print("+++++++++++++++++++++++++++++++++++++++single symbol+++++++++++++++++++++++++++++++++++")

tree, encoded_data = huffman_encoding_func(content)
print("The size of the encoded data is: {}".format(sys.getsizeof(int(encoded_data, base=2))))
print("The content of the encodded data is: {}".format(encoded_data))
decoded_data = huffman_decoding_func(encoded_data, tree)
print("The size of the decoded data is: {}".format(sys.getsizeof(decoded_data)))
print("The content of the decoded data is: {}".format(decoded_data))

print("+++++++++++++++++++++++++++++++++++++++par symbol++++++++++++++++++++++++++++++++++++++")

tree_par, encoded_data_par = huffman_encoding_func_par(content)
print("The size of the encoded data is: {}".format(sys.getsizeof(int(encoded_data_par, base=2))))
print("The content of the encoded data is: {}".format(encoded_data_par))
decoded_data_par = huffman_decoding_func_par(encoded_data_par, tree_par)
print("The size of the decoded data is: {}".format(sys.getsizeof(decoded_data_par)))
print("The content of the decoded data is: {}".format(decoded_data_par))

print("+++++++++++++++++++++++++++++++++++++++summary++++++++++++++++++++++++++++++++++++++")
print("The size of the data is: {}".format(sys.getsizeof(content)))
print("(single) The size of the encoded data is: {}".format(sys.getsizeof(int(encoded_data, base=2))))
print("(single) The size of the decoded data is: {}".format(sys.getsizeof(decoded_data)))
print("(par)    The size of the encoded data is: {}".format(sys.getsizeof(int(encoded_data_par, base=2))))
print("(par)    The size of the decoded data is: {}".format(sys.getsizeof(decoded_data_par)))




print("+++++++++++++++++++++++++++++++++++++++IMAGE++++++++++++++++++++++++++++++++++++++")

file_path = "../../../../data/obrazy_testowe/peppers.pgm"
# file_path = "../../../../data/obrazy_testowe/boat.pgm"
# file_path = "../../../../data/obrazy_testowe/lena.pgm"
# file_path = "../../../../data/obrazy_testowe/mandril.pgm"
# file_path = "../../../../data/obrazy_testowe/chronometer.pgm"
# file_path = "../../../../data/obrazy_testowe/barbara.pgm"

image = Image.open(file_path)
image_array = np.array(image)
print(image_array)

print("+++++++++++++++++++++++++++++++++++++++par image++++++++++++++++++++++++++++++++++++++")


print("The size of the data is: {}".format(sys.getsizeof(image_array)))
tree_image, encoded_data_image = huffman_encoding_image_par(image_array)
print("The size of the encoded data is: {}".format(sys.getsizeof(int(encoded_data_image, base=2))))
# print("The content of the encodded data is: {}".format(encoded_data_image))
decoded_image = huffman_decoding_image_par( encoded_data_image,tree_image)
print("The size of the decoded data is: {}".format(sys.getsizeof(decoded_image)))
# print("The content of the decoded data is: {}".format(decoded_image))


size_image_array = image_array.nbytes
size_decoded_image = decoded_image.nbytes

are_arrays_equal = np.array_equal(image_array, decoded_image)


if are_arrays_equal:
    print("Tablice są identyczne.")
else:
    print("Tablice różnią się od siebie.")

