from node_class import Node
from tree_class import Tree
from collections import defaultdict
import numpy as np
import pickle
from pgm_reader import Reader

import matplotlib.pyplot as plt

added = False

class HuffmanBlock:
    def __init__(self, file=None, mode='string', file_name='encoded_file', decode=False):
        self.forest = {}
        self.first_sign = ''
        self.file_name = file_name + ".pkl"
        if mode not in ['string', 'image']:
            raise ValueError(f"error, {mode} is not described as one of the possible arguments")

        self.mode = mode

        if decode:
            with open(file, "rb") as f:
                loaded_file = pickle.load(f)
                print(f'Object successfully loaded from "{file}"')
                if self.mode == 'image':
                    self.size = loaded_file[3]
                self.first_sign = loaded_file[0]
                self.forest = loaded_file[1]
                decoded_file = self.decode(loaded_file[2])
                imgplot = plt.imshow(decoded_file)
                plt.show()

        else:
            if self.mode == 'image':
                reader = Reader()
                file = reader.read_pgm(file)
                self.size = np.shape(file)[0]
                file = np.concatenate(file, axis=0)
            self.encode(file)

    def encode(self, file):

        if self.mode == 'string':
            self.tree, self.encoded_file  = self.huffman_encoding_func_par(file)
            to_save = [self.first_sign, self.tree, self.encoded_file]
        elif self.mode == 'image':
            self.tree, self.encoded_file = self.huffman_encoding_image_par(file)
            to_save = [self.first_sign, self.tree, self.encoded_file, self.size]

        with open(self.file_name, 'wb') as file:
            pickle.dump(to_save, file)
            print(f'Object successfully saved to "{self.file_name}"')

    def decode(self,encoded_file):
        if self.mode == 'string':
            self.decoded_file = self.huffman_decoding_func_par(encoded_file, self.tree)
            return self.decoded_file
        elif self.mode == 'image':
            self.decoded_file = self.huffman_decoding_image_par(encoded_file)
            return self.decoded_file

    def _calculateBlockChains(self, string_file) -> dict:
        d = {}
        for i in range(len(string_file) - 1):
            if string_file[i] not in d.keys():
                d[string_file[i]] = {}
            if string_file[i + 1] in d[string_file[i]].keys():
                d[string_file[i]][string_file[i + 1]] += 1
            else:
                d[string_file[i]][string_file[i + 1]] = 1
        return d
    def limit_pairs(self,symbol_pairs, max_pairs=4):
        symbol_counts = defaultdict(int)
        limited_pairs = []

        for pair in symbol_pairs:
            symbol1, symbol2 = pair
            if symbol_counts[symbol1] < max_pairs and symbol_counts[symbol2] < max_pairs:
                limited_pairs.append(pair)
                symbol_counts[symbol1] += 1
                symbol_counts[symbol2] += 1
        return limited_pairs
    def formatuj_liczby(self,liczby_str):
        liczby = liczby_str.split()
        sformatowane_liczby = [f"{int(liczba):03d}" for liczba in liczby]
        sformatowany_ciag = ' '.join(sformatowane_liczby)
        return sformatowany_ciag

    def return_frequency_par(self,data):

        frequency = {}
        if len(data)%2==1:
            data=data+"+"
            global added
            added=True
        pairs = set(data[i:i+2] for i in range(0, len(data), 2))

        for pair in pairs:
            for i in range(len(data)):
                if data[i:i + 2] == pair:
                    if pair in frequency:
                        frequency[pair] += 1
                    else:
                        frequency[pair] = 1
        lst = [(v, k) for k, v in frequency.items()]
        lst.sort(reverse=True)
        return lst


    def return_frequency_image_par(self,data):
        frequency = {}
        buffor_pairs=[]
        x=str(data[0]) + str(data[1])
        y = str(data[2]) + str(data[3])

        pairs = set(str(data[i]).zfill(3)+str(data[i+1]).zfill(3) for i in range(0, len(data), 2))

        for i in range(0, len(data), 2):
            buffor_pairs.append(str(data[i]).zfill(3) + str(data[i + 1]).zfill(3))
        leng = len(buffor_pairs)
        for item in pairs:
            for i in range(0, leng):
                if buffor_pairs[i]==item:
                    if item in frequency:
                        frequency[item] += 1
                    else:
                        frequency[item] = 1

        lst = [(v, k) for k, v in frequency.items()]

        lst.sort(reverse=True)

        return lst
    # Function to sort values while building the Huffman tree
    def sort_values(self,nodes_list, node):
        node_value, _ = node.value
        index = 0
        max_index = len(nodes_list)
        while True:
            if index == max_index:
                nodes_list.append(node)
                return
            current_val, _ = nodes_list[index].value
            if current_val <= node_value:
                nodes_list.insert(index, node)
                return
            index += 1



    # Function to build the Huffman tree for character pairs
    def build_tree_par(self,data):
        if len(data)%2==1:
            data=data+"+"
            global added
            added = True
        lst =  self.return_frequency_par(data)
        nodes_list = []
        for node_value in lst:
            node = Node(node_value)
            nodes_list.append(node)

        while len(nodes_list) != 1:
            first_node = nodes_list.pop()
            second_node = nodes_list.pop()

            val1, char1 = first_node.value
            val2, char2 = second_node.value

            node = Node((val1 + val2, char1 + char2))
            node.set_left_child(second_node)
            node.set_right_child(first_node)
            self.sort_values(nodes_list, node)

        root = nodes_list[0]
        tree = Tree()
        tree.root = root
        return tree
    # Function to build the Huffman tree for image


    # Function to build the Huffman tree for character pairs image
    def build_tree_image_par(self,data):
        lst =  self.return_frequency_image_par(data)

        nodes_list = []
        for node_value in lst:
            node = Node(node_value)
            nodes_list.append(node)

        while len(nodes_list) != 1:
            first_node = nodes_list.pop()
            second_node = nodes_list.pop()

            val1, char1 = first_node.value
            val2, char2 = second_node.value

            node = Node((val1 + val2, char1 + char2))
            node.set_left_child(second_node)
            node.set_right_child(first_node)
            self.sort_values(nodes_list, node)

        root = nodes_list[0]
        tree = Tree()
        tree.root = root
        return tree

    # Function to get Huffman codes for individual characters
    def get_codes(self,root):
        if root is None:
            return {}

        _, characters = root.value
        char_dict = dict([(i, '') for i in list(characters)])
        left_branch =  self.get_codes(root.get_left_child())
        for key, value in left_branch.items():
            char_dict[key] += '0' + left_branch[key]
        right_branch =  self.get_codes(root.get_right_child())
        for key, value in right_branch.items():
            char_dict[key] += '1' + right_branch[key]
        return char_dict

    # Function to get Huffman codes for character pairs
    def get_codes_par(self,root):
        if root is None:
            return {}

        _, characters = root.value
        symbol_pairs = [characters[i:i + 2] for i in range(0, len(characters), 2)]
        char_dict = dict([(pair, '') for pair in symbol_pairs])
        left_branch =  self.get_codes_par(root.get_left_child())
        for key, value in left_branch.items():
            char_dict[key] += '0' + left_branch[key]
        right_branch =  self.get_codes_par(root.get_right_child())
        for key, value in right_branch.items():
            char_dict[key] += '1' + right_branch[key]
        return char_dict


    # Function to get Huffman codes for character pairs for image
    def get_codes_image_par(self,root):
        if root is None:
            return {}

        _, characters = root.value
        symbol_pairs = [characters[i:i + 6] for i in range(0, len(characters), 6)]

        char_dict = dict([(pair, '') for pair in symbol_pairs])

        left_branch =  self.get_codes_image_par(root.get_left_child())

        for key, value in left_branch.items():

            char_dict[key] += '0' + left_branch[key]
        right_branch =  self.get_codes_image_par(root.get_right_child())
        for key, value in right_branch.items():
            char_dict[key] += '1' + right_branch[key]

        return char_dict

    # Function to perform Huffman encoding for individual characters

    def huffman_encoding_func_par(self,data):
        if data == '':
            return None, ''
        print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
        if len(data)%2==1:

            data=data+"+"
            global added
            added = True
        tree =  self.build_tree_par(data)
        dict =  self.get_codes_par(tree.root)
        codes = ''
        for i in range(0, len(data), 2):
            char_pair = data[i:i + 2]
            codes += dict[char_pair]
        return tree, codes


    # Function to encode an image par (2D array of integers)
    def huffman_encoding_image_par(self,image_data):
        if image_data.size == 0:
            return None, ''

        flat_data = np.array(image_data).flatten()

        flat_data_int = flat_data.astype(int)
        shape_x, shape_y = image_data.shape
        new_array = [0,shape_x,0,shape_y]

        flat_data_with_shape = np.insert(flat_data_int, 0, new_array)

        tree =  self.build_tree_image_par(flat_data)

        dict =  self.get_codes_image_par(tree.root)

        codes = ''

        for i in range(0,len(flat_data),2):
            image_pair=str(flat_data[i]).zfill(3)+str(flat_data[i+1]).zfill(3)

            codes += dict[image_pair]

        return tree, codes

    # Function to perform Huffman decoding for individual characters

    # Function to perform Huffman decoding for character pairs
    def huffman_decoding_func_par(self,data, tree):
        if data == '':
            return ''
        dict = self.get_codes_par(tree.root)
        reversed_dict = {}

        for key, value in dict.items():
            if value not in reversed_dict:
                reversed_dict[value] = key
            else:
                if not isinstance(reversed_dict[value], list):
                    reversed_dict[value] = [reversed_dict[value]]
                reversed_dict[value].append(key)

        start_index = 0
        end_index = 1
        max_index = len(data)
        s = ''

        while start_index != max_index:
            if data[start_index : end_index] in reversed_dict:
                s += reversed_dict[data[start_index : end_index]]
                start_index = end_index
            end_index += 1
        global added
        if (added == True):
            s = s[:-1]
        return s

    # NEW Function to decode an image (2D array of integers)

    def huffman_decoding_image_par(self,data, tree):
        if data == '':
            return ''

        dict =  self.get_codes_image_par(tree.root)
        reversed_dict = {}

        for value, key in dict.items():
            reversed_dict[key] = value

        start_index = 0
        end_index = 1
        max_index = len(data)
        s = ''
        bu=0
        xx=0
        yy=0
        # while start_index != max_index:
        #     if data[start_index: end_index] in reversed_dict:
        #         buffor = reversed_dict[data[start_index: end_index]]
        #
        #         if (bu==0):
        #             xx=int(buffor[3] + buffor[4] + buffor[5])
        #         if (bu==1):
        #             yy=int(buffor[3] + buffor[4] + buffor[5])
        #         start_index = end_index
        #         end_index += 1
        #         bu=bu+1
        #         if(bu==2):
        #             break;
        #     end_index += 1

        new_array = np.zeros((self.size, self.size), dtype=np.uint8)

        i=0
        j=0
        while start_index != max_index:
            if data[start_index : end_index] in reversed_dict:

                s += reversed_dict[data[start_index : end_index]]
                buffor=reversed_dict[data[start_index: end_index]]

                new_array[j, i] = int(buffor[0]+buffor[1]+buffor[2])
                i=i+1
                new_array[j, i] = int(buffor[3] + buffor[4] + buffor[5])
                i = i + 1
                if i==self.size:
                    i=0
                    j=j+1

                start_index = end_index
            end_index += 1
        return new_array
    def get_last_code(self):
        if self.encoded_file:
            return self.encoded_file
        else:
            raise ValueError(f"error, no encoded file in memory")

if __name__ == '__main__':
    string_input = """Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia,
    molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum
    numquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium
    optio, eaque rerum! Provident similique accusantium nemo autem. Veritatis
    obcaecati tenetur iure eius earum ut molestias architecto voluptate aliquam
    nihil, eveniet aliquid culpa officia aut! Impedit sit sunt quaerat, odit,
    tenetur error, harum nesciunt ipsum debitis quas aliquid."""
    print(string_input)
    x = HuffmanBlock(string_input)

    # print(f'Average number of signs per character: {sign_count/len(string_input)}')
    x.decode(x.get_last_code())