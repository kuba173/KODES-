import numpy as np
import os
import pandas as pd
import itertools
import matplotlib.pyplot as plt
from numpy import log2
from Block_encoding_and_decoding import *
from src.main.metrics.utils import *
import time
from PIL import Image


def simple_entropy2(probabilities) -> float:
    fun = lambda prob: prob * log2(prob)
    return -fun(probabilities[probabilities != 0]).sum()


def calculate_block_entropy(data):
    blocks = []
    for i in list(range(1,len(data))):
        blocks.append(f"{data[i-1]}{data[i]}")
    frequencies = np.unique(blocks, return_counts=True)
    probs = frequencies[1]/frequencies[1].sum()
    return simple_entropy2(probs)


def calculate_block_probs2(data):
    blocks = []
    for i in list(range(1, len(data))):
        blocks.append(f"{data[i - 1]}{data[i]}")
    frequencies = np.unique(blocks, return_counts=True)
    probabilities = []
    sum = frequencies[1].sum()
    for symbol, frequency in zip(frequencies[0], frequencies[1]):
        probabilities.append((symbol, frequency / sum))
    probabilities_df = pd.DataFrame(probabilities, columns=["id", "prob"])
    return probabilities_df


def get_symbols_length2(image_codes_dict):
    symbols_length = []
    for (key, value) in image_codes_dict.items():
        new_key = f"{int(key[:3])}{int(key[3:])}"
        symbols_length.append((new_key, len(value)))
    symbols_length.sort()
    symbols_length_df = pd.DataFrame(symbols_length, columns=["id", "length"])
    return symbols_length_df



def block_calculate_metrics(data_pd_df):
    data = []
    for _, row in data_pd_df.iterrows():
        image_name = row["image_name"]
        image = Image.open(f"{data_base_path}/{image_name}")
        image_array = np.array(image)
        encoding_start_time = time.time()
        tree_image, encoded_data_image = huffman_encoding_image_par(image_array)
        encoding_end_time = time.time()
        decoding_start_time = time.time()
        decoded_image = huffman_decoding_image_par(encoded_data_image, tree_image)
        decoding_end_time = time.time()
        probabilities = calculate_block_probs2(np.array(row["data"]).flatten())
        symbols_length = get_symbols_length2(get_codes_image_par(tree_image.root))
        merged_df = pd.merge(symbols_length, probabilities, on='id', how='inner')
        avg_code_length = np.sum([x[0] * x[1] for x in merged_df[["length", "prob"]].to_records(index=False)]) / 2
        encoding_time = encoding_end_time - encoding_start_time
        decoding_time = decoding_end_time - decoding_start_time
        overall_time = encoding_time + decoding_time
        input_img_bits_cnt = image_array.size * 8
        encoded_img_bits_cnt = len(encoded_data_image)
        compression_ratio = encoded_img_bits_cnt / input_img_bits_cnt
        compression_factor = 1 / compression_ratio
        metrics_row = (
        image_name, avg_code_length, encoding_time, decoding_time, overall_time, compression_ratio, compression_factor)
        data.append(metrics_row)
    return pd.DataFrame(data
                        , columns=["image_name", "avg_code_length", "encoding_time", "decoding_time", "overall_time",
                                   "compression_ratio", "compression_factor"])

#######################################
data_base_path = "../../../../data/obrazy_testowe/"
imgs = []
block_entropies = []

distribution_data_files = os.listdir(os.path.abspath(data_base_path))


distribution_data = []
for file in distribution_data_files:
    pgmReader = PgmReader(os.path.join(data_base_path,file))
    read_data = pgmReader.read()
    distribution_data.append([file,read_data])
    imgs.append(file)

distribution_data_df = pd.DataFrame(distribution_data,columns=["image_name","data"])
for _, row in distribution_data_df.iterrows():
    generate_histogram(row, data_base_path)

block_metrics_test_images = block_calculate_metrics(distribution_data_df)
print(block_metrics_test_images)
print(" z mojego kodu ")


################################################
probabilites = []





def format_number(number):
    return str(number).zfill(3)

def calculate_block_entropy_2(data):
    blocks = []
    for i in list(range(0,len(data),2)):
        blocks.append(str(data[i]).zfill(3) + str(data[i + 1]).zfill(3))
    frequencies = np.unique(blocks, return_counts=True)
    probs = frequencies[1]/frequencies[1].sum()
    return simple_entropy2(probs)



print("saaaaa")
for _, row in distribution_data_df.iterrows():

    result = [format_number(num) for num in np.array(row["data"]).flatten()]

    markov_input = np.array(row["data"]).flatten()
    markov = MarkovEntropy(markov_input)

    block_entropies.append(calculate_block_entropy_2(result) / 2)

print(imgs)
print(block_entropies)
if len(imgs) == len(block_entropies):
    for img, entropy in zip(imgs, block_entropies):
        print(f"Image: {img}, Entropy: {entropy}")
else:
    print("Listy imgs i block_entropies mają różne długości.")
