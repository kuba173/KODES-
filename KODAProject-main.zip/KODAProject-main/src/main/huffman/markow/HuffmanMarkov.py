from Node import Node as Node
from typing import List
import heapq
import numpy as np
import pickle
from pgm_reader import Reader
from PIL import Image
import matplotlib.pyplot as plt

class HuffmanMarkov:
    def __init__(self,file=None,mode ='string',file_name = 'encoded_file',decode = False):
        self.forest = {}
        self.first_sign = ''
        self.file_name = file_name+".pkl"
        if mode not in ['string', 'image']:
            raise ValueError(f"error, {mode} is not described as one of the possible arguments")
        
        self.mode = mode

        if decode:
            with open(file, "rb") as f:
                loaded_file = pickle.load(f)
                print(f'Object successfully loaded from "{file}"')
                if self.mode == 'image':
                    self.size = loaded_file[3]
                self.first_sign = loaded_file[0]
                self.forest = loaded_file[1]
                decoded_file = self.decode(loaded_file[2])
                imgplot = plt.imshow(decoded_file)
                plt.show()
                
        else:
            if self.mode == 'image':
                reader = Reader()
                file = reader.read_pgm(file)
                self.size = np.shape(file)[0]
                file = np.concatenate(file,axis = 0)
            self._buildForest(self._calculateMarkovChains(file))
            self.encode(file)

    def encode(self,file):

        if self.mode == 'string':
            self.encoded_file = self._encodeString(file)
            to_save = [self.first_sign,self.forest,self.encoded_file]
        elif self.mode == 'image':
            self.encoded_file =self._encodeImage(file)
            to_save = [self.first_sign,self.forest,self.encoded_file,self.size]
        
        
        with open(self.file_name, 'wb') as file:
            pickle.dump(to_save, file)
            print(f'Object successfully saved to "{self.file_name}"')

    def decode(self,encoded_file):
        if self.mode == 'string':
            self.decoded_file = self._decode_string(encoded_file)
            return self.decoded_file
        elif self.mode == 'image':
            self.decoded_file = self._decodeImage(encoded_file)
            return self.decoded_file
    


    def _decode_string(self,code_list):
        last_sign = self.first_sign
        result = last_sign
        for code in code_list[1:]:
            last_sign = self.forest[last_sign][0].follow(code)[0]
            result += str(last_sign)
        return result
    
    def _encodeString(self,string_file):
        self.first_sign = string_file[0]
        result = ['0']
        last_sign = string_file[0]
        for sign in string_file[1:]:
            if self.forest[last_sign][0].is_leaf():
                result.append('0')
            else:
                result.append(self.forest[last_sign][0].find(sign))
            # self.forest[last_sign][0].show()
            last_sign = sign
        return result
    
    def _decodeImage(self,code_image):
        last_sign = self.first_sign
        result = [last_sign]
        for code in code_image[1:]:
            last_sign = self.forest[last_sign][0].follow(code)[0]
            result.append(last_sign)
        
        return np.array_split(result,self.size)
    
    def _encodeImage(self,string_file):
        self.first_sign = string_file[0]
        result = ['0']
        last_sign = string_file[0]
        for sign in string_file[1:]:
            if self.forest[last_sign][0].is_leaf():
                result.append('0')
            else:
                result.append(self.forest[last_sign][0].find(sign)) 
            # self.forest[last_sign][0].show()
            last_sign = sign
        return result
    
    def _buildForest(self,probabilities: dict):
        for k,v in probabilities.items():
            self.forest[k] = []
            for key,item in v.items():
                heapq.heappush(self.forest[k], Node(key, item))
            self._buildTree(self.forest[k])

    def _buildTree(self, nodes: List[Node]) -> Node:
        while len(nodes) >1 :
            left = heapq.heappop(nodes) 
            right = heapq.heappop(nodes) 
            left.direction = "0"
            right.direction = "1"
            newNode = Node(np.concatenate([left.character,right.character],axis=0), left.frequency+right.frequency, left, right)
            heapq.heappush(nodes, newNode)
        return nodes[0]
    
    def _calculateMarkovChains(self,string_file) -> dict:
        d = {}
        for i in range(len(string_file)-1):
            if string_file[i] not in d.keys():
                d[string_file[i]] = {}
            if string_file[i+1] in d[string_file[i]].keys():
                d[string_file[i]][string_file[i+1]] += 1
            else:
                d[string_file[i]][string_file[i+1]] = 1
        return d
    
    def get_last_code(self):
        if self.encoded_file:
            return self.encoded_file
        else:
            raise ValueError(f"error, no encoded file in memory")
    def get_last_decoded_file(self):
        if self.decoded_file:
            return self.decoded_file
        else:
            raise ValueError(f"error, no decoded file in memory")
if __name__ == '__main__':
    string_input = """Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime mollitia,
molestiae quas vel sint commodi repudiandae consequuntur voluptatum laborum
numquam blanditiis harum quisquam eius sed odit fugiat iusto fuga praesentium
optio, eaque rerum! Provident similique accusantium nemo autem. Veritatis
obcaecati tenetur iure eius earum ut molestias architecto voluptate aliquam
nihil, eveniet aliquid culpa officia aut! Impedit sit sunt quaerat, odit,
tenetur error, harum nesciunt ipsum debitis quas aliquid."""
    print(string_input)
    x = HuffmanMarkov(string_input)
    sign_count = 0
    for code in x.get_last_code():
        sign_count += len(code)
    # print(f'Average number of signs per character: {sign_count/len(string_input)}')
    x.decode(x.get_last_code())
    