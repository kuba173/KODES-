import numpy as np
class Node:

    def __init__(self,character,frequency,left = None ,right = None,direction = None):
        if  isinstance(character,np.ndarray) or isinstance(character,list):
            self.character = character
        else: 
            self.character = [character]
        self.frequency = frequency
        self.left = left
        self.right = right
        self.direction = direction

    def __lt__(self, nxt): 
        return self.frequency < nxt.frequency 

    def __str__(self):
        return f'Char: {self.character}, freq: {self.frequency}'
    def is_leaf(self):
        return self.left==None and self.right ==None

    def show(self,level = 0):
        if self.left:
            self.left.show(level + 1)
        print(' ' * 4 * level + '-> ' + 'C:'+str(self.character)+',F: ' +str(self.frequency)+' ,D: '+str(self.direction))
        if self.right:
            self.right.show(level + 1)

    def find(self,sign,directions = ''):
        if self.left and sign in self.left.character:
            return self.left.find(sign,directions + self.left.direction)
        elif self.right and sign in self.right.character:
            return self.right.find(sign,directions + self.right.direction)
        else:
            return directions

    def follow(self, code):
        if self.is_leaf():
            return self.character
        if code[0] == '0':
            return self.left.follow(code[1:])
        else:
            return self.right.follow(code[1:])


                

if __name__ == '__main__':
    # This code won't run if this file is imported.
    test_root = Node('oebs',10,
                     Node('oe',3, 
                        Node('o',1,direction = "0"),
                        Node('e',2,direction = "1"),'0'),
                     Node('bs',7,
                        Node('b',3,direction = '0'),
                        Node('s',4,direction = '1'),'1'))
    print('Code: '+test_root.find('s'))
    test_root.show()
