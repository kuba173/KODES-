import sys
import numpy as np
from PIL import Image
import pickle

from huffman_encoding_and_decoding import huffman_encoding_func, huffman_encoding_image

class HuffmanEncoder:
    def __init__(self, text_file, image_file):
        self.text_file = text_file
        self.image_file = image_file

    def save_text_to_pickle(self, tree, encoded_data):
        with open(self.text_file, 'wb') as file:
            pickle.dump((tree, encoded_data), file)
            print(f'Tekst został zapisany w pliku "{self.text_file}"')

    def save_image_to_pickle(self, tree, encoded_data, image_size):
        with open(self.image_file, 'wb') as file:
            pickle.dump((tree, encoded_data, image_size), file)
            print(f'Obraz został zapisany w pliku "{self.image_file}"')

# Kod dla tekstu
print("+++++++++++++++++++++++++++++++++++++++SZYFROWANIE TEKSTU+++++++++++++++++++++++++++++++++++")
with open("data.txt", "r") as file:
    content = file.read()
print("Treść pliku: \n{}".format(content))
print("Rozmiar pliku: {}".format(sys.getsizeof(content)))

tree_text, encoded_data_text = huffman_encoding_func(content)

encoder = HuffmanEncoder("encoded_text.pkl", "encoded_image.pkl")
encoder.save_text_to_pickle(tree_text, encoded_data_text)

# Kod dla obrazu
print("+++++++++++++++++++++++++++++++++++++SZYFROWANIE OBRAZU++++++++++++++++++++++++++++++++++++++++")
file_path = 'C:/obrazy_testowe/peppers.pgm'
#file_path = 'C:/obrazy_testowe/boat.pgm'
#file_path = 'C:/obrazy_testowe/lena.pgm'
#file_path = 'C:/obrazy_testowe/mandril.pgm'
#file_path = 'C:/obrazy_testowe/chronometer.pgm'
#file_path = 'C:/obrazy_testowe/barbara.pgm'
image = Image.open(file_path)
image_array = np.array(image)

print("Obraz: \n{}".format(image_array))
print("Rozmiar obrazu: {}".format(sys.getsizeof(image_array)))

tree_image, encoded_data_image = huffman_encoding_image(image_array)
encoder.save_image_to_pickle(tree_image, encoded_data_image, image_array.shape)






