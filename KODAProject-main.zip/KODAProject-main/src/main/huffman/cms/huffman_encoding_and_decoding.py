from node_class import Node
from tree_class import Tree

import numpy as np
import pickle

class Huffman_Discrete_Memoryless_Source
    def __init__(self, file=None, mode='string', file_name='encoded_file', decode=False):
        self.forest = {}
        self.first_sign = ''
        self.file_name = file_name + ".pkl"
        if mode not in ['string', 'image']:
            raise ValueError(f"error, {mode} is not described as one of the possible arguments")

        self.mode = mode

        if huffman_decoding_func:
            with open(file, "rb") as f:
                loaded_file = pickle.load(f)
                print(f'Object successfully loaded from "{file}"')
                if self.mode == 'image':
                    self.size = loaded_file[3]
                self.first_sign = loaded_file[0]
                self.forest = loaded_file[1]
                decoded_file = self.decode(loaded_file[2])
                imgplot = plt.imshow(decoded_file)
                plt.show()

        else:
            if self.mode == 'image':
                reader = Reader()
                file = reader.read_pgm(file)
                self.size = np.shape(file)[0]
                file = np.concatenate(file, axis=0)
            self._buildForest(self._calculateMarkovChains(file))
            self.encode(file)

    # Funkcja ograniczająca liczbę par symboli w danych wejściowych
    def formatuj_liczby(liczby_str):
        liczby = liczby_str.split()
        sformatowane_liczby = [f"{int(liczba):03d}" for liczba in liczby]
        sformatowany_ciąg = ' '.join(sformatowane_liczby)
        return sformatowany_ciąg

    # Funkcja zwracająca częstotliwość występowania liczb dla szyfrowanego tekstu
    def return_frequency(data):

        frequency = {}
        for char in data:
            if char in frequency:
                frequency[char] += 1
            else:
                frequency[char] = 1
        lst = [(v, k) for k, v in frequency.items()]
        lst.sort(reverse=True)
        return lst

    # Funkcja zwracająca częstotliwość występowania liczb dla szyfrowaengo obrazu
    def return_frequency_image(data):
        frequency = {}
        for item in data:
            item = str(item)
            if item in frequency:
                frequency[item] += 1
            else:
                frequency[item] = 1
        lst = [(v, formatuj_liczby(k)) for k, v in frequency.items()]

        lst.sort(reverse=True)

        return lst

    # Funkcja do sortowania wartości
    def sort_values(nodes_list, node):
        node_value, _ = node.value
        index = 0
        max_index = len(nodes_list)
        while True:
            if index == max_index:
                nodes_list.append(node)
                return
            current_val, _ = nodes_list[index].value
            if current_val <= node_value:
                nodes_list.insert(index, node)
                return
            index += 1

    # Funkcja budująca drzewo Huffmana dla tekstu
    def build_tree(data):
        lst = return_frequency(data)

        nodes_list = []
        for node_value in lst:
            node = Node(node_value)
            nodes_list.append(node)

        while len(nodes_list) != 1:
            first_node = nodes_list.pop()
            second_node = nodes_list.pop()

            val1, char1 = first_node.value
            val2, char2 = second_node.value

            node = Node((val1 + val2, char1 + char2))
            node.set_left_child(second_node)
            node.set_right_child(first_node)
            sort_values(nodes_list, node)

        root = nodes_list[0]
        tree = Tree()
        tree.root = root
        return tree

    # # Funckja budująca drzewo Huffmana dla obrazu
    def build_tree_image(data):
        lst = return_frequency_image(data)

        nodes_list = []
        for node_value in lst:
            node = Node(node_value)
            nodes_list.append(node)

        while len(nodes_list) != 1:
            first_node = nodes_list.pop()
            second_node = nodes_list.pop()

            val1, char1 = first_node.value
            val2, char2 = second_node.value

            node = Node((val1 + val2, char1 + char2))
            node.set_left_child(second_node)
            node.set_right_child(first_node)
            sort_values(nodes_list, node)

        root = nodes_list[0]
        tree = Tree()
        tree.root = root
        return tree

    # Funkcja pozwalająca uzyskać kody Huffmana dla tekstu
    def get_codes(root):
        if root is None:
            return {}

        _, characters = root.value
        char_dict = dict([(i, '') for i in list(characters)])
        left_branch = get_codes(root.get_left_child())
        for key, value in left_branch.items():
            char_dict[key] += '0' + left_branch[key]
        right_branch = get_codes(root.get_right_child())
        for key, value in right_branch.items():
            char_dict[key] += '1' + right_branch[key]
        return char_dict

    # Funkcja pozwalająca uzyskać kody Huffmana dla obrazu
    def get_codes_image(root):
        if root is None:
            return {}

        _, characters = root.value

        symbol_pairs = [characters[i:i + 3] for i in range(0, len(characters), 3)]

        char_dict = dict([(pair, '') for pair in symbol_pairs])

        left_branch = get_codes_image(root.get_left_child())
        for key, value in left_branch.items():
            char_dict[key] += '0' + left_branch[key]

        right_branch = get_codes_image(root.get_right_child())
        for key, value in right_branch.items():
            char_dict[key] += '1' + right_branch[key]

        return char_dict

    # Szyfrowanie Huffmana dla tekstu
    def huffman_encoding_func(data):
        if data == '':
            return None, ''

        tree = build_tree(data)
        dict = get_codes(tree.root)
        codes = ''
        for char in data:
            codes += dict[char]
        return tree, codes

    # Szyfrowanie Huffmana dla obrazu
    def huffman_encoding_image(image_data):
        if image_data.size == 0:
            return None, ''

        flat_data = np.array(image_data).flatten()

        tree = build_tree_image(flat_data)

        dict = get_codes_image(tree.root)

        codes = ''

        for char in flat_data:

            codes += dict[formatuj_liczby(str(char))]
        return tree, codes

    # Deszyfrowanie Huffmana dla tekstu
    def huffman_decoding_func(data, tree):
        if data == '':
            return ''

        dict = get_codes(tree.root)
        reversed_dict = {}

        for value, key in dict.items():
            reversed_dict[key] = value

        start_index = 0
        end_index = 1
        max_index = len(data)
        s = ''

        while start_index != max_index:
            if data[start_index : end_index] in reversed_dict:
                s += reversed_dict[data[start_index : end_index]]
                start_index = end_index
            end_index += 1

        return s

    # Deszyfrowanie Huffmana dla obrazu
    def huffman_decoding_image(data, tree, original_shape):
        if data == '':
            return ''

        dict = get_codes_image(tree.root)

        reversed_dict = {}

        for value, key in dict.items():
            reversed_dict[key] = value

        start_index = 0
        end_index = 1
        max_index = len(data)
        s = ''
        new_array = np.zeros((original_shape[0], original_shape[1]), dtype=np.uint8)

        i=0
        j=0
        while start_index != max_index:
            if data[start_index : end_index] in reversed_dict:
                s += reversed_dict[data[start_index : end_index]]
                new_array[j,i]=int(reversed_dict[data[start_index : end_index]])
                i=i+1
                if i==original_shape[0]:
                    i=0
                    j=j+1
                start_index = end_index
            end_index += 1

        return new_array
