import sys
import pickle

from huffman_encoding_and_decoding import huffman_decoding_func, huffman_decoding_image

class HuffmanDecoder:
    def __init__(self, text_file, image_file):
        self.text_file = text_file
        self.image_file = image_file

    def load_text_from_pickle(self):
        with open(self.text_file, 'rb') as file:
            loaded_data = pickle.load(file)
        return loaded_data

    def load_image_from_pickle(self):
        with open(self.image_file, 'rb') as file:
            loaded_data = pickle.load(file)
        return loaded_data

decoder_text = HuffmanDecoder("encoded_text.pkl", "encoded_image.pkl")
# Wczytywanie zakodowanego tekstu
print("+++++++++++++++++++++++++++++++++++++++ODSZYFROWANIE TEKSTU+++++++++++++++++++++++++++++++++++")

loaded_tree_text, loaded_encoded_text = decoder_text.load_text_from_pickle()
decoded_text = huffman_decoding_func(loaded_encoded_text, loaded_tree_text)

print("Treść rozszyfrowanego pliku: \n{}".format(decoded_text))
print("Rozmiar rozzaszyfrowanego pliku: {}".format(sys.getsizeof(decoded_text)))


# Wczytywanie zakodowanego obrazu
print("+++++++++++++++++++++++++++++++++++++++ODSZYFROWANIE OBRAZU+++++++++++++++++++++++++++++++++++")
loaded_tree_image, loaded_encoded_data_image, image_size = decoder_text.load_image_from_pickle()
decoded_image = huffman_decoding_image(loaded_encoded_data_image, loaded_tree_image, image_size)

print("Obraz: \n{}".format(decoded_image))
print("Rozmiar odszyfrowanego obrazu: {}".format(sys.getsizeof(decoded_image)))