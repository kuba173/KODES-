import argparse
from huffman.markow.HuffmanMarkov import HuffmanMarkov as HM
from huffman.cms.huffman_encoding_and_decoding import Huffman_Discrete_Memoryless_Source as DMS

if __name__ == "__main__":
    """
    Run as:
    python main.py --method --mode --file_path --save_path
    """

    parser = argparse.ArgumentParser(description='Huffman encoder/decoder')
    parser.add_argument('--method', type=str, required=True, help='method to use')
    parser.add_argument('--mode', type=str, required=True, help='whether to decode/encode')
    parser.add_argument('--file_path', type=str, required=True, help='path to file to encode/decode')
    parser.add_argument('--save_path', type=str, required=True, help='path where to save file')

    args = parser.parse_args()

    if args.mode == 'decode':
        decode = True
    else:
        decode = False
    
    HM(file = args.file_path, mode = 'image',file_name = args.save_path, decode = decode)

    print('DONE')
