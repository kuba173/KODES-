# KODAProject
## Harmonogram Projektu
1. DONE - Zapis do grup projektowych - do 20 X
2. TODO - Analiza literatury, wybór narzędzi programistycznych, metod oceny efektywności - do 24 XI
3. TODO -  Wstępne Wyniki implementacji/testowania algorytmu - do 15 XII
4. TODO - Zakończenie projektu: sprawozdanie, wyniki testów, kody źródłowe - do 26 I 

## Podział zadań

- model źródła informacji - Maciej Skłodowski
- model blokowy rzędu 2 - Jakub Kiernozek
- model Markowa - Krzysztof Miśków
- Testy, histogram i oceny - Jakub Karpiński

### model źródła informacji - Maciej Skłodowski 
#### Analiza literatury
1. https://esezam.okno.pw.edu.pl/mod/book/view.php?id=70&chapterid=1509
2. https://github.com/tjazerzen/Huffman_encoding_decoding
#### Wybór narzędzi programistycznych
Python 3.10
#### Metod oceny efektywności
TODO
### model blokowy rzędu 2 - Jakub Kiernozek
#### Analiza literatury
1. https://pl.wikipedia.org/wiki/Kodowanie_Huffmana
2. https://home.agh.edu.pl/~turcza/ts/1_Huffman.pdf
3. https://github.com/TapirLab/huffman
4. https://github.com/DeBukkIt/Huffman-Encoder
5. prawdopodobieństwa dla symboli AA...DD należy wyznaczyć z danych, a nie obliczyć z pomnożenia prawdopodobieństw symboli 'prostych'.
#### Wybór narzędzi programistycznych
Python 3.10
#### Metod oceny efektywności
TODO
### model Markowa - Krzysztof Miśków
#### Analiza literatury
1. https://github.com/jeremy-rifkin/Markov-Huffman-Coding#encoding-details
2. http://www.sm.luth.se/csee/courses/sms/047/2006/lectures/Lecture4_4.pdf
3. https://github.com/Wittline/Huffman-decoding
4. https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=9081983
#### Wybór narzędzi programistycznych
Python 3.10
#### Metod oceny efektywności
TODO

### Testy, histogram i oceny - Jakub Karpiński
